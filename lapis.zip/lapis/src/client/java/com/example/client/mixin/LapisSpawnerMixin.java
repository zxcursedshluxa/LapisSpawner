package com.example.client.mixin;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.block.entity.MobSpawnerBlockEntity;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.entity.EntityType;
import net.minecraft.util.math.BlockPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(ClientWorld.class)
public class LapisSpawnerMixin {

    @Inject(method = "getBlockEntity", at = @At("HEAD"), cancellable = true)
    private void onGetBlockEntity(BlockPos pos, CallbackInfoReturnable<BlockEntity> cir) {
        ClientWorld world = (ClientWorld) (Object) this;
        BlockState state = world.getBlockState(pos);

        if (state.isOf(Blocks.LAPIS_BLOCK)) {
            MobSpawnerBlockEntity spawner = new MobSpawnerBlockEntity(pos, Blocks.SPAWNER.getDefaultState());
            spawner.getLogic().setEntityId(EntityType.CREEPER, world);
            cir.setReturnValue(spawner);
        }
    }
}